﻿namespace HotelBookingSystemAPI.Models
{
    public class ReservationAgent
    {
    }
}
