﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HotelBookingSystemAPI.Data;
using HotelBookingSystemAPI.Models;

namespace HotelBookingSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomBookedsController : ControllerBase
    {
        private readonly DataContext _context;

        public RoomBookedsController(DataContext context)
        {
            _context = context;
        }

        // GET: api/RoomBookeds
        [HttpGet]
        public async Task<ActionResult<IEnumerable<RoomBooked>>> GetRoomsBooked()
        {
          if (_context.RoomsBooked == null)
          {
              return NotFound();
          }
            return await _context.RoomsBooked.ToListAsync();
        }

        // GET: api/RoomBookeds/5
        [HttpGet("{id}")]
        public async Task<ActionResult<RoomBooked>> GetRoomBooked(int id)
        {
          if (_context.RoomsBooked == null)
          {
              return NotFound();
          }
            var roomBooked = await _context.RoomsBooked.FindAsync(id);

            if (roomBooked == null)
            {
                return NotFound();
            }

            return roomBooked;
        }

        // PUT: api/RoomBookeds/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRoomBooked(int id, RoomBooked roomBooked)
        {
            if (id != roomBooked.Id)
            {
                return BadRequest();
            }

            _context.Entry(roomBooked).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RoomBookedExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/RoomBookeds
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<RoomBooked>> PostRoomBooked(RoomBooked roomBooked)
        {
          if (_context.RoomsBooked == null)
          {
              return Problem("Entity set 'DataContext.RoomsBooked'  is null.");
          }
            _context.RoomsBooked.Add(roomBooked);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetRoomBooked", new { id = roomBooked.Id }, roomBooked);
        }

        // DELETE: api/RoomBookeds/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRoomBooked(int id)
        {
            if (_context.RoomsBooked == null)
            {
                return NotFound();
            }
            var roomBooked = await _context.RoomsBooked.FindAsync(id);
            if (roomBooked == null)
            {
                return NotFound();
            }

            _context.RoomsBooked.Remove(roomBooked);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool RoomBookedExists(int id)
        {
            return (_context.RoomsBooked?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
